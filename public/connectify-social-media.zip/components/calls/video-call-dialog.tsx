"use client"

import { useState, useEffect } from "react"
import { Dialog, DialogContent } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Video, VideoOff, Mic, MicOff, PhoneOff, Monitor, Settings } from "lucide-react"

interface VideoCallDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  contact: {
    name: string
    avatar: string
  }
}

export function VideoCallDialog({ open, onOpenChange, contact }: VideoCallDialogProps) {
  const [isConnected, setIsConnected] = useState(false)
  const [isMuted, setIsMuted] = useState(false)
  const [isVideoOn, setIsVideoOn] = useState(true)
  const [callDuration, setCallDuration] = useState(0)

  useEffect(() => {
    let interval: NodeJS.Timeout
    if (isConnected) {
      interval = setInterval(() => {
        setCallDuration((prev) => prev + 1)
      }, 1000)
    }
    return () => clearInterval(interval)
  }, [isConnected])

  useEffect(() => {
    if (open) {
      // Simulate connecting
      const timer = setTimeout(() => {
        setIsConnected(true)
      }, 3000)
      return () => clearTimeout(timer)
    } else {
      setIsConnected(false)
      setCallDuration(0)
    }
  }, [open])

  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`
  }

  const endCall = () => {
    setIsConnected(false)
    setCallDuration(0)
    onOpenChange(false)
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl h-[80vh] p-0 bg-black text-white">
        <div className="relative h-full flex flex-col">
          {/* Video Area */}
          <div className="flex-1 relative bg-gradient-to-br from-gray-900 to-black">
            {!isConnected ? (
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <Avatar className="w-24 h-24 mb-4">
                  <AvatarImage src={contact.avatar || "/placeholder.svg"} alt={contact.name} />
                  <AvatarFallback className="text-2xl">{contact.name.charAt(0)}</AvatarFallback>
                </Avatar>
                <h3 className="text-xl font-semibold mb-2">{contact.name}</h3>
                <p className="text-gray-400">Connecting...</p>
                <div className="flex space-x-1 mt-4">
                  <div className="w-2 h-2 bg-white rounded-full animate-bounce"></div>
                  <div
                    className="w-2 h-2 bg-white rounded-full animate-bounce"
                    style={{ animationDelay: "0.1s" }}
                  ></div>
                  <div
                    className="w-2 h-2 bg-white rounded-full animate-bounce"
                    style={{ animationDelay: "0.2s" }}
                  ></div>
                </div>
              </div>
            ) : (
              <>
                {/* Remote Video */}
                <div className="absolute inset-0 bg-gradient-to-br from-blue-900/20 to-purple-900/20 flex items-center justify-center">
                  <Avatar className="w-32 h-32">
                    <AvatarImage src={contact.avatar || "/placeholder.svg"} alt={contact.name} />
                    <AvatarFallback className="text-4xl">{contact.name.charAt(0)}</AvatarFallback>
                  </Avatar>
                </div>

                {/* Local Video (Picture-in-Picture) */}
                <div className="absolute top-4 right-4 w-48 h-36 bg-gray-800 rounded-lg overflow-hidden border-2 border-white/20">
                  {isVideoOn ? (
                    <div className="w-full h-full bg-gradient-to-br from-green-900/20 to-blue-900/20 flex items-center justify-center">
                      <div className="text-white/60 text-sm">Your Video</div>
                    </div>
                  ) : (
                    <div className="w-full h-full bg-gray-900 flex items-center justify-center">
                      <VideoOff className="w-8 h-8 text-white/60" />
                    </div>
                  )}
                </div>

                {/* Call Info */}
                <div className="absolute top-4 left-4 bg-black/50 backdrop-blur-sm rounded-lg p-3">
                  <p className="text-white font-medium">{contact.name}</p>
                  <p className="text-white/70 text-sm">{formatDuration(callDuration)}</p>
                </div>
              </>
            )}
          </div>

          {/* Controls */}
          <div className="p-6 bg-black/80 backdrop-blur-sm">
            <div className="flex items-center justify-center space-x-4">
              <Button
                size="lg"
                variant={isMuted ? "destructive" : "secondary"}
                className="rounded-full w-12 h-12"
                onClick={() => setIsMuted(!isMuted)}
              >
                {isMuted ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
              </Button>

              <Button
                size="lg"
                variant={isVideoOn ? "secondary" : "destructive"}
                className="rounded-full w-12 h-12"
                onClick={() => setIsVideoOn(!isVideoOn)}
              >
                {isVideoOn ? <Video className="w-5 h-5" /> : <VideoOff className="w-5 h-5" />}
              </Button>

              <Button size="lg" variant="secondary" className="rounded-full w-12 h-12">
                <Monitor className="w-5 h-5" />
              </Button>

              <Button size="lg" variant="secondary" className="rounded-full w-12 h-12">
                <Settings className="w-5 h-5" />
              </Button>

              <Button
                size="lg"
                variant="destructive"
                className="rounded-full w-12 h-12 bg-red-500 hover:bg-red-600"
                onClick={endCall}
              >
                <PhoneOff className="w-5 h-5" />
              </Button>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}
