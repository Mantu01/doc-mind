"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Plus, Camera, ImageIcon, Video, Type } from "lucide-react"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { CreatePostDialog } from "@/components/posts/create-post-dialog"

export function FloatingActionButton() {
  const [showCreatePost, setShowCreatePost] = useState(false)
  const [postType, setPostType] = useState<"text" | "image" | "video" | "camera">("text")

  const handleCreatePost = (type: "text" | "image" | "video" | "camera") => {
    setPostType(type)
    setShowCreatePost(true)
  }

  return (
    <>
      <div className="fixed bottom-6 right-6 z-50">
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button
              size="lg"
              className="h-14 w-14 rounded-full shadow-lg hover:shadow-xl transition-all duration-300 ghibli-button"
            >
              <Plus className="w-6 h-6" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-48">
            <DropdownMenuItem onClick={() => handleCreatePost("text")}>
              <Type className="mr-2 h-4 w-4" />
              Text Post
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => handleCreatePost("image")}>
              <ImageIcon className="mr-2 h-4 w-4" />
              Photo Post
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => handleCreatePost("video")}>
              <Video className="mr-2 h-4 w-4" />
              Video Post
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => handleCreatePost("camera")}>
              <Camera className="mr-2 h-4 w-4" />
              Take Photo/Video
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>

      <CreatePostDialog open={showCreatePost} onOpenChange={setShowCreatePost} type={postType} />
    </>
  )
}
