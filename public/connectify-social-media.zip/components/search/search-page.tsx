"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Search, Users, Hash, ImageIcon, TrendingUp } from "lucide-react"
import { PostCard } from "@/components/posts/post-card"

const mockUsers = [
  {
    id: "1",
    name: "Alice Johnson",
    username: "alice_j",
    avatar: "/placeholder.svg?height=40&width=40",
    followers: "2.1K",
    bio: "Digital artist & Studio Ghibli enthusiast ✨",
    isFollowing: false,
  },
  {
    id: "2",
    name: "Bob Smith",
    username: "bob_smith",
    avatar: "/placeholder.svg?height=40&width=40",
    followers: "1.8K",
    bio: "Nature photographer 📸 Capturing magical moments",
    isFollowing: true,
  },
  {
    id: "3",
    name: "Carol Davis",
    username: "carol_d",
    avatar: "/placeholder.svg?height=40&width=40",
    followers: "3.2K",
    bio: "UI/UX Designer creating magical experiences",
    isFollowing: false,
  },
]

const mockPosts = [
  {
    id: "1",
    user: {
      name: "Alice Johnson",
      username: "alice_j",
      avatar: "/placeholder.svg?height=40&width=40",
    },
    content:
      "Just finished reading an amazing book about Studio Ghibli! The art and storytelling are absolutely magical ✨",
    timestamp: "2 hours ago",
    likes: 24,
    comments: 8,
    shares: 3,
    isLiked: false,
    images: [],
  },
  {
    id: "2",
    user: {
      name: "Bob Smith",
      username: "bob_smith",
      avatar: "/placeholder.svg?height=40&width=40",
    },
    content: "Beautiful sunset today! Nature never fails to amaze me 🌅",
    timestamp: "4 hours ago",
    likes: 156,
    comments: 23,
    shares: 12,
    isLiked: true,
    images: ["/placeholder.svg?height=300&width=400"],
  },
]

const trendingTopics = [
  { topic: "#StudioGhibli", posts: "12.5K", color: "ghibli-accent-green" },
  { topic: "#Nature", posts: "8.2K", color: "ghibli-accent-blue" },
  { topic: "#Photography", posts: "6.7K", color: "ghibli-accent-orange" },
  { topic: "#Art", posts: "5.1K", color: "ghibli-accent-pink" },
  { topic: "#Magic", posts: "3.9K", color: "ghibli-accent-green" },
]

export function SearchPage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [activeTab, setActiveTab] = useState("all")

  const filteredUsers = mockUsers.filter(
    (user) =>
      user.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      user.username.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  const filteredPosts = mockPosts.filter((post) => post.content.toLowerCase().includes(searchQuery.toLowerCase()))

  return (
    <div className="space-y-6">
      <Card className="ghibli-card ghibli-gradient-subtle">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Search className="w-5 h-5 text-primary" />
            Search Connectify
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
            <Input
              placeholder="Search for users, posts, hashtags..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 rounded-full bg-background/50 border-border/50"
            />
          </div>
        </CardContent>
      </Card>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-4 bg-card/50 backdrop-blur-sm">
          <TabsTrigger value="all">All</TabsTrigger>
          <TabsTrigger value="users">Users</TabsTrigger>
          <TabsTrigger value="posts">Posts</TabsTrigger>
          <TabsTrigger value="hashtags">Hashtags</TabsTrigger>
        </TabsList>

        <TabsContent value="all" className="space-y-6">
          {searchQuery && (
            <>
              <Card className="ghibli-card">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Users className="w-5 h-5 text-blue-500" />
                    Users ({filteredUsers.length})
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {filteredUsers.slice(0, 3).map((user) => (
                    <div key={user.id} className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <Avatar>
                          <AvatarImage src={user.avatar || "/placeholder.svg"} alt={user.name} />
                          <AvatarFallback>{user.name.charAt(0)}</AvatarFallback>
                        </Avatar>
                        <div>
                          <p className="font-medium">{user.name}</p>
                          <p className="text-sm text-muted-foreground">
                            @{user.username} • {user.followers} followers
                          </p>
                          <p className="text-xs text-muted-foreground">{user.bio}</p>
                        </div>
                      </div>
                      <Button
                        size="sm"
                        variant={user.isFollowing ? "outline" : "default"}
                        className={user.isFollowing ? "bg-transparent" : "ghibli-button-blue"}
                      >
                        {user.isFollowing ? "Following" : "Follow"}
                      </Button>
                    </div>
                  ))}
                </CardContent>
              </Card>

              <Card className="ghibli-card">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <ImageIcon className="w-5 h-5 text-green-500" />
                    Posts ({filteredPosts.length})
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {filteredPosts.slice(0, 2).map((post) => (
                    <PostCard key={post.id} post={post} />
                  ))}
                </CardContent>
              </Card>
            </>
          )}

          {!searchQuery && (
            <Card className="ghibli-card">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="w-5 h-5 text-orange-500" />
                  Trending Now
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {trendingTopics.map((item, index) => (
                  <div
                    key={item.topic}
                    className={`p-3 rounded-lg ${item.color} cursor-pointer hover:shadow-md transition-all`}
                  >
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="font-medium text-primary">{item.topic}</p>
                        <p className="text-sm text-muted-foreground">{item.posts} posts</p>
                      </div>
                      <Badge variant="secondary" className="text-xs">
                        #{index + 1}
                      </Badge>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="users" className="space-y-4">
          {filteredUsers.map((user) => (
            <Card key={user.id} className="ghibli-card">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <Avatar className="w-12 h-12">
                      <AvatarImage src={user.avatar || "/placeholder.svg"} alt={user.name} />
                      <AvatarFallback>{user.name.charAt(0)}</AvatarFallback>
                    </Avatar>
                    <div>
                      <p className="font-medium">{user.name}</p>
                      <p className="text-sm text-muted-foreground">
                        @{user.username} • {user.followers} followers
                      </p>
                      <p className="text-xs text-muted-foreground mt-1">{user.bio}</p>
                    </div>
                  </div>
                  <Button
                    size="sm"
                    variant={user.isFollowing ? "outline" : "default"}
                    className={user.isFollowing ? "bg-transparent" : "ghibli-button"}
                  >
                    {user.isFollowing ? "Following" : "Follow"}
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </TabsContent>

        <TabsContent value="posts" className="space-y-4">
          {filteredPosts.map((post) => (
            <PostCard key={post.id} post={post} />
          ))}
        </TabsContent>

        <TabsContent value="hashtags" className="space-y-3">
          {trendingTopics.map((item, index) => (
            <Card
              key={item.topic}
              className={`ghibli-card ${item.color} cursor-pointer hover:shadow-lg transition-all`}
            >
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <Hash className="w-5 h-5 text-primary" />
                    <div>
                      <p className="font-medium text-primary">{item.topic}</p>
                      <p className="text-sm text-muted-foreground">{item.posts} posts</p>
                    </div>
                  </div>
                  <Badge variant="secondary" className="text-xs">
                    Trending #{index + 1}
                  </Badge>
                </div>
              </CardContent>
            </Card>
          ))}
        </TabsContent>
      </Tabs>
    </div>
  )
}
