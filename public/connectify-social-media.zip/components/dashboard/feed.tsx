"use client"

import { PostCard } from "@/components/posts/post-card"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Sparkles } from "lucide-react"

const mockPosts = [
  {
    id: "1",
    user: {
      name: "Alice Johnson",
      username: "alice_j",
      avatar: "/placeholder.svg?height=40&width=40",
    },
    content:
      "Just finished reading an amazing book about Studio Ghibli! The art and storytelling are absolutely magical ✨",
    timestamp: "2 hours ago",
    likes: 24,
    comments: 8,
    shares: 3,
    isLiked: false,
    images: [],
  },
  {
    id: "2",
    user: {
      name: "Bob Smith",
      username: "bob_smith",
      avatar: "/placeholder.svg?height=40&width=40",
    },
    content: "Beautiful sunset today! Nature never fails to amaze me 🌅",
    timestamp: "4 hours ago",
    likes: 156,
    comments: 23,
    shares: 12,
    isLiked: true,
    images: ["/placeholder.svg?height=300&width=400"],
  },
  {
    id: "3",
    user: {
      name: "Carol Davis",
      username: "carol_d",
      avatar: "/placeholder.svg?height=40&width=40",
    },
    content:
      "Working on a new project! Excited to share it with everyone soon. The design is inspired by magical forests and floating islands 🏝️",
    timestamp: "6 hours ago",
    likes: 89,
    comments: 15,
    shares: 7,
    isLiked: false,
    images: [],
  },
]

export function Feed() {
  return (
    <div className="space-y-6">
      <Card className="ghibli-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-primary" />
            Your Feed
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-muted-foreground">Discover magical moments from people you follow</p>
        </CardContent>
      </Card>

      <div className="space-y-4">
        {mockPosts.map((post) => (
          <PostCard key={post.id} post={post} />
        ))}
      </div>
    </div>
  )
}
