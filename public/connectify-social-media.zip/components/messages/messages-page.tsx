"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { ScrollArea } from "@/components/ui/scroll-area"
import { MessageCircle, Search, Phone, Video, MoreVertical, Send, Smile, Paperclip, Users, Plus } from "lucide-react"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { VideoCallDialog } from "@/components/calls/video-call-dialog"
import { AudioCallDialog } from "@/components/calls/audio-call-dialog"

const mockChats = [
  {
    id: "1",
    type: "individual",
    name: "Alice Johnson",
    username: "alice_j",
    avatar: "/placeholder.svg?height=40&width=40",
    lastMessage: "Hey! How are you doing?",
    timestamp: "2 min ago",
    unreadCount: 2,
    isOnline: true,
  },
  {
    id: "2",
    type: "individual",
    name: "Bob Smith",
    username: "bob_smith",
    avatar: "/placeholder.svg?height=40&width=40",
    lastMessage: "Thanks for sharing that photo!",
    timestamp: "1 hour ago",
    unreadCount: 0,
    isOnline: false,
  },
  {
    id: "3",
    type: "group",
    name: "Photography Enthusiasts",
    avatar: "/placeholder.svg?height=40&width=40",
    lastMessage: "Sarah: Check out this amazing sunset!",
    timestamp: "3 hours ago",
    unreadCount: 5,
    memberCount: 12,
  },
  {
    id: "4",
    type: "individual",
    name: "Carol Davis",
    username: "carol_d",
    avatar: "/placeholder.svg?height=40&width=40",
    lastMessage: "See you tomorrow!",
    timestamp: "1 day ago",
    unreadCount: 0,
    isOnline: true,
  },
  {
    id: "5",
    type: "group",
    name: "Design Team",
    avatar: "/placeholder.svg?height=40&width=40",
    lastMessage: "Mike: The new mockups are ready",
    timestamp: "2 days ago",
    unreadCount: 1,
    memberCount: 8,
  },
]

const mockMessages = [
  {
    id: "1",
    senderId: "alice_j",
    senderName: "Alice Johnson",
    content: "Hey! How are you doing?",
    timestamp: "10:30 AM",
    isOwn: false,
  },
  {
    id: "2",
    senderId: "me",
    senderName: "You",
    content: "I'm doing great! Just finished working on a new project. How about you?",
    timestamp: "10:32 AM",
    isOwn: true,
  },
  {
    id: "3",
    senderId: "alice_j",
    senderName: "Alice Johnson",
    content: "That sounds exciting! I'd love to hear more about it. I've been working on some digital art lately.",
    timestamp: "10:35 AM",
    isOwn: false,
  },
  {
    id: "4",
    senderId: "me",
    senderName: "You",
    content: "Digital art is amazing! Are you still doing the Studio Ghibli inspired pieces?",
    timestamp: "10:37 AM",
    isOwn: true,
  },
  {
    id: "5",
    senderId: "alice_j",
    senderName: "Alice Johnson",
    content: "Yes! I just finished a piece inspired by Spirited Away. The colors came out so magical ✨",
    timestamp: "10:40 AM",
    isOwn: false,
  },
]

export function MessagesPage() {
  const [selectedChat, setSelectedChat] = useState(mockChats[0])
  const [messages, setMessages] = useState(mockMessages)
  const [newMessage, setNewMessage] = useState("")
  const [searchQuery, setSearchQuery] = useState("")
  const [showVideoCall, setShowVideoCall] = useState(false)
  const [showAudioCall, setShowAudioCall] = useState(false)

  const filteredChats = mockChats.filter(
    (chat) =>
      chat.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (chat.username && chat.username.toLowerCase().includes(searchQuery.toLowerCase())),
  )

  const sendMessage = () => {
    if (!newMessage.trim()) return

    const message = {
      id: Date.now().toString(),
      senderId: "me",
      senderName: "You",
      content: newMessage,
      timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
      isOwn: true,
    }

    setMessages((prev) => [...prev, message])
    setNewMessage("")
  }

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault()
      sendMessage()
    }
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 h-[calc(100vh-8rem)]">
      {/* Chat List */}
      <Card className="ghibli-card lg:col-span-1">
        <CardContent className="p-0 h-full flex flex-col">
          <div className="p-4 border-b border-border/50">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-semibold flex items-center gap-2">
                <MessageCircle className="w-5 h-5 text-primary" />
                Messages
              </h2>
              <Button size="icon" variant="ghost" className="ghibli-button">
                <Plus className="w-4 h-4" />
              </Button>
            </div>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
              <Input
                placeholder="Search conversations..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 rounded-full bg-muted/50"
              />
            </div>
          </div>

          <ScrollArea className="flex-1">
            <div className="p-2">
              {filteredChats.map((chat) => (
                <div
                  key={chat.id}
                  className={`p-3 rounded-xl cursor-pointer transition-all duration-200 hover:bg-muted/50 ${
                    selectedChat.id === chat.id ? "bg-primary/10 border border-primary/20" : ""
                  }`}
                  onClick={() => setSelectedChat(chat)}
                >
                  <div className="flex items-center gap-3">
                    <div className="relative">
                      <Avatar>
                        <AvatarImage src={chat.avatar || "/placeholder.svg"} alt={chat.name} />
                        <AvatarFallback>{chat.name.charAt(0)}</AvatarFallback>
                      </Avatar>
                      {chat.type === "individual" && chat.isOnline && (
                        <div className="absolute -bottom-1 -right-1 w-3 h-3 bg-green-500 rounded-full border-2 border-background" />
                      )}
                      {chat.type === "group" && (
                        <div className="absolute -bottom-1 -right-1 bg-blue-500 rounded-full p-1">
                          <Users className="w-2 h-2 text-white" />
                        </div>
                      )}
                    </div>

                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between">
                        <p className="font-medium truncate">{chat.name}</p>
                        <div className="flex items-center gap-2">
                          <span className="text-xs text-muted-foreground">{chat.timestamp}</span>
                          {chat.unreadCount > 0 && (
                            <Badge className="bg-primary text-primary-foreground text-xs">{chat.unreadCount}</Badge>
                          )}
                        </div>
                      </div>
                      <p className="text-sm text-muted-foreground truncate">{chat.lastMessage}</p>
                      {chat.type === "group" && (
                        <p className="text-xs text-muted-foreground">{chat.memberCount} members</p>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </ScrollArea>
        </CardContent>
      </Card>

      {/* Chat Window */}
      <Card className="ghibli-card lg:col-span-2">
        <CardContent className="p-0 h-full flex flex-col">
          {/* Chat Header */}
          <div className="p-4 border-b border-border/50 ghibli-gradient-subtle">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="relative">
                  <Avatar>
                    <AvatarImage src={selectedChat.avatar || "/placeholder.svg"} alt={selectedChat.name} />
                    <AvatarFallback>{selectedChat.name.charAt(0)}</AvatarFallback>
                  </Avatar>
                  {selectedChat.type === "individual" && selectedChat.isOnline && (
                    <div className="absolute -bottom-1 -right-1 w-3 h-3 bg-green-500 rounded-full border-2 border-background" />
                  )}
                </div>
                <div>
                  <p className="font-medium">{selectedChat.name}</p>
                  <p className="text-sm text-muted-foreground">
                    {selectedChat.type === "individual"
                      ? selectedChat.isOnline
                        ? "Online"
                        : "Last seen recently"
                      : `${selectedChat.memberCount} members`}
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                {selectedChat.type === "individual" && (
                  <>
                    <Button
                      size="icon"
                      variant="ghost"
                      onClick={() => setShowAudioCall(true)}
                      className="hover:bg-pink-100 dark:hover:bg-pink-900/20"
                    >
                      <Phone className="w-4 h-4 text-pink-500" />
                    </Button>
                    <Button
                      size="icon"
                      variant="ghost"
                      onClick={() => setShowVideoCall(true)}
                      className="hover:bg-orange-100 dark:hover:bg-orange-900/20"
                    >
                      <Video className="w-4 h-4 text-orange-500" />
                    </Button>
                  </>
                )}
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button size="icon" variant="ghost">
                      <MoreVertical className="w-4 h-4" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuItem>View Profile</DropdownMenuItem>
                    <DropdownMenuItem>Mute Notifications</DropdownMenuItem>
                    <DropdownMenuItem>Clear Chat</DropdownMenuItem>
                    {selectedChat.type === "group" && <DropdownMenuItem>Leave Group</DropdownMenuItem>}
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>
            </div>
          </div>

          {/* Messages */}
          <ScrollArea className="flex-1 p-4">
            <div className="space-y-4">
              {messages.map((message) => (
                <div key={message.id} className={`flex ${message.isOwn ? "justify-end" : "justify-start"}`}>
                  <div
                    className={`max-w-[70%] p-3 rounded-2xl ${
                      message.isOwn ? "bg-primary text-primary-foreground ml-auto" : "bg-muted"
                    }`}
                  >
                    <p className="text-sm">{message.content}</p>
                    <p
                      className={`text-xs mt-1 ${
                        message.isOwn ? "text-primary-foreground/70" : "text-muted-foreground"
                      }`}
                    >
                      {message.timestamp}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </ScrollArea>

          {/* Message Input */}
          <div className="p-4 border-t border-border/50">
            <div className="flex items-center gap-2">
              <Button size="icon" variant="ghost">
                <Paperclip className="w-4 h-4" />
              </Button>
              <div className="flex-1 relative">
                <Input
                  placeholder="Type a message..."
                  value={newMessage}
                  onChange={(e) => setNewMessage(e.target.value)}
                  onKeyPress={handleKeyPress}
                  className="rounded-full pr-12"
                />
                <Button size="icon" variant="ghost" className="absolute right-1 top-1/2 transform -translate-y-1/2">
                  <Smile className="w-4 h-4" />
                </Button>
              </div>
              <Button
                size="icon"
                onClick={sendMessage}
                disabled={!newMessage.trim()}
                className="ghibli-button rounded-full"
              >
                <Send className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Call Dialogs */}
      <VideoCallDialog open={showVideoCall} onOpenChange={setShowVideoCall} contact={selectedChat} />
      <AudioCallDialog open={showAudioCall} onOpenChange={setShowAudioCall} contact={selectedChat} />
    </div>
  )
}
