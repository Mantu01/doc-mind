import { NotificationsPage } from "@/components/notifications/notifications-page"

export default function Notifications() {
  return <NotificationsPage />
}
