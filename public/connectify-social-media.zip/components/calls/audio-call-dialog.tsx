"use client"

import { useState, useEffect } from "react"
import { Dialog, DialogContent } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Mic, MicOff, PhoneOff, Volume2, VolumeX } from "lucide-react"

interface AudioCallDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  contact: {
    name: string
    avatar: string
  }
}

export function AudioCallDialog({ open, onOpenChange, contact }: AudioCallDialogProps) {
  const [isConnected, setIsConnected] = useState(false)
  const [isMuted, setIsMuted] = useState(false)
  const [isSpeakerOn, setIsSpeakerOn] = useState(true)
  const [callDuration, setCallDuration] = useState(0)

  useEffect(() => {
    let interval: NodeJS.Timeout
    if (isConnected) {
      interval = setInterval(() => {
        setCallDuration((prev) => prev + 1)
      }, 1000)
    }
    return () => clearInterval(interval)
  }, [isConnected])

  useEffect(() => {
    if (open) {
      // Simulate connecting
      const timer = setTimeout(() => {
        setIsConnected(true)
      }, 2000)
      return () => clearTimeout(timer)
    } else {
      setIsConnected(false)
      setCallDuration(0)
    }
  }, [open])

  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`
  }

  const endCall = () => {
    setIsConnected(false)
    setCallDuration(0)
    onOpenChange(false)
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md p-0 bg-gradient-to-br from-pink-500 via-purple-500 to-blue-500">
        <div className="relative h-[500px] flex flex-col text-white">
          {/* Background Pattern */}
          <div className="absolute inset-0 bg-black/20 backdrop-blur-sm"></div>

          <div className="relative flex-1 flex flex-col items-center justify-center p-8">
            {/* Avatar */}
            <Avatar className="w-32 h-32 mb-6 ring-4 ring-white/30">
              <AvatarImage src={contact.avatar || "/placeholder.svg"} alt={contact.name} />
              <AvatarFallback className="text-4xl bg-white/20">{contact.name.charAt(0)}</AvatarFallback>
            </Avatar>

            {/* Contact Info */}
            <h3 className="text-2xl font-semibold mb-2">{contact.name}</h3>

            {!isConnected ? (
              <>
                <p className="text-white/80 mb-4">Calling...</p>
                <div className="flex space-x-1">
                  <div className="w-2 h-2 bg-white rounded-full animate-bounce"></div>
                  <div
                    className="w-2 h-2 bg-white rounded-full animate-bounce"
                    style={{ animationDelay: "0.1s" }}
                  ></div>
                  <div
                    className="w-2 h-2 bg-white rounded-full animate-bounce"
                    style={{ animationDelay: "0.2s" }}
                  ></div>
                </div>
              </>
            ) : (
              <>
                <p className="text-white/80 mb-2">Connected</p>
                <p className="text-white/60 text-lg">{formatDuration(callDuration)}</p>

                {/* Audio Visualizer */}
                <div className="flex items-center space-x-1 mt-6">
                  {[...Array(5)].map((_, i) => (
                    <div
                      key={i}
                      className="w-1 bg-white/60 rounded-full animate-pulse"
                      style={{
                        height: `${Math.random() * 20 + 10}px`,
                        animationDelay: `${i * 0.1}s`,
                        animationDuration: "1s",
                      }}
                    />
                  ))}
                </div>
              </>
            )}
          </div>

          {/* Controls */}
          <div className="relative p-6">
            <div className="flex items-center justify-center space-x-6">
              <Button
                size="lg"
                variant={isMuted ? "destructive" : "secondary"}
                className="rounded-full w-14 h-14 bg-white/20 hover:bg-white/30 border-white/30"
                onClick={() => setIsMuted(!isMuted)}
              >
                {isMuted ? <MicOff className="w-6 h-6" /> : <Mic className="w-6 h-6" />}
              </Button>

              <Button
                size="lg"
                variant="destructive"
                className="rounded-full w-16 h-16 bg-red-500 hover:bg-red-600"
                onClick={endCall}
              >
                <PhoneOff className="w-6 h-6" />
              </Button>

              <Button
                size="lg"
                variant={isSpeakerOn ? "secondary" : "outline"}
                className="rounded-full w-14 h-14 bg-white/20 hover:bg-white/30 border-white/30"
                onClick={() => setIsSpeakerOn(!isSpeakerOn)}
              >
                {isSpeakerOn ? <Volume2 className="w-6 h-6" /> : <VolumeX className="w-6 h-6" />}
              </Button>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}
