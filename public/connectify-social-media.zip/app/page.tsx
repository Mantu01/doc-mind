import { AuthPage } from "@/components/auth/auth-page"

export default function Home() {
  return <AuthPage />
}
