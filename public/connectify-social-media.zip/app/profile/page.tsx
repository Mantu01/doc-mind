import { ProfilePage } from "@/components/profile/profile-page"

export default function Profile() {
  return <ProfilePage />
}
