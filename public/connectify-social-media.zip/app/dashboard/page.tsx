import { Feed } from "@/components/dashboard/feed"
import { TrendingTopics } from "@/components/dashboard/trending-topics"
import { SuggestedUsers } from "@/components/dashboard/suggested-users"

export default function Dashboard() {
  return (
    <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
      <div className="lg:col-span-3">
        <Feed />
      </div>
      <div className="space-y-6">
        <TrendingTopics />
        <SuggestedUsers />
      </div>
    </div>
  )
}
