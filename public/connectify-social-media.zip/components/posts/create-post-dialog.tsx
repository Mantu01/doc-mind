"use client"

import type React from "react"

import { useState, useRef } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { ImageIcon, VideoIcon, CameraIcon, XIcon } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

interface CreatePostDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  type: "text" | "image" | "video" | "camera"
}

export function CreatePostDialog({ open, onOpenChange, type }: CreatePostDialogProps) {
  const [content, setContent] = useState("")
  const [selectedFiles, setSelectedFiles] = useState<File[]>([])
  const [isLoading, setIsLoading] = useState(false)
  const fileInputRef = useRef<HTMLInputElement>(null)
  const { toast } = useToast()

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || [])
    setSelectedFiles((prev) => [...prev, ...files])
  }

  const removeFile = (index: number) => {
    setSelectedFiles((prev) => prev.filter((_, i) => i !== index))
  }

  const handleSubmit = async () => {
    if (!content.trim() && selectedFiles.length === 0) {
      toast({
        title: "Error",
        description: "Please add some content to your post.",
        variant: "destructive",
      })
      return
    }

    setIsLoading(true)

    // Simulate post creation
    setTimeout(() => {
      setIsLoading(false)
      toast({
        title: "Post created!",
        description: "Your post has been shared successfully.",
      })
      setContent("")
      setSelectedFiles([])
      onOpenChange(false)
    }, 1000)
  }

  const getDialogTitle = () => {
    switch (type) {
      case "image":
        return "Create Photo Post"
      case "video":
        return "Create Video Post"
      case "camera":
        return "Take Photo/Video"
      default:
        return "Create Post"
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>{getDialogTitle()}</DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          <div className="flex items-start gap-3">
            <Avatar>
              <AvatarImage src="/placeholder.svg?height=40&width=40" alt="Your avatar" />
              <AvatarFallback>JD</AvatarFallback>
            </Avatar>
            <div className="flex-1">
              <Textarea
                placeholder="What's on your mind?"
                value={content}
                onChange={(e) => setContent(e.target.value)}
                className="min-h-[100px] resize-none border-none p-0 text-lg placeholder:text-muted-foreground focus-visible:ring-0"
              />
            </div>
          </div>

          {selectedFiles.length > 0 && (
            <div className="grid grid-cols-2 gap-2">
              {selectedFiles.map((file, index) => (
                <div key={index} className="relative group">
                  <div className="aspect-square bg-muted rounded-lg flex items-center justify-center">
                    {file.type.startsWith("image/") ? (
                      <ImageIcon className="w-8 h-8 text-muted-foreground" />
                    ) : (
                      <VideoIcon className="w-8 h-8 text-muted-foreground" />
                    )}
                  </div>
                  <Button
                    variant="destructive"
                    size="icon"
                    className="absolute -top-2 -right-2 w-6 h-6 opacity-0 group-hover:opacity-100 transition-opacity"
                    onClick={() => removeFile(index)}
                  >
                    <XIcon className="w-3 h-3" />
                  </Button>
                  <p className="text-xs text-muted-foreground mt-1 truncate">{file.name}</p>
                </div>
              ))}
            </div>
          )}

          <div className="flex items-center justify-between pt-4 border-t">
            <div className="flex items-center gap-2">
              <input
                ref={fileInputRef}
                type="file"
                accept={type === "video" ? "video/*" : type === "image" ? "image/*" : "image/*,video/*"}
                multiple
                className="hidden"
                onChange={handleFileSelect}
              />

              {type !== "camera" && (
                <Button variant="ghost" size="icon" onClick={() => fileInputRef.current?.click()}>
                  {type === "video" ? <VideoIcon className="w-4 h-4" /> : <ImageIcon className="w-4 h-4" />}
                </Button>
              )}

              {type === "camera" && (
                <Button variant="ghost" size="icon">
                  <CameraIcon className="w-4 h-4" />
                </Button>
              )}
            </div>

            <div className="flex items-center gap-2">
              <Button variant="outline" onClick={() => onOpenChange(false)}>
                Cancel
              </Button>
              <Button onClick={handleSubmit} disabled={isLoading} className="ghibli-button">
                {isLoading ? "Posting..." : "Post"}
              </Button>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}
