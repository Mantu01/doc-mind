import { MessagesPage } from "@/components/messages/messages-page"

export default function Messages() {
  return <MessagesPage />
}
