import { SearchPage } from "@/components/search/search-page"

export default function Search() {
  return <SearchPage />
}
