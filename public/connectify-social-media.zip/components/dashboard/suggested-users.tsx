import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { UserPlus } from "lucide-react"

const suggestedUsers = [
  {
    name: "Emma Wilson",
    username: "emma_w",
    avatar: "/placeholder.svg?height=40&width=40",
    followers: "2.1K",
  },
  {
    name: "David Chen",
    username: "david_c",
    avatar: "/placeholder.svg?height=40&width=40",
    followers: "1.8K",
  },
  {
    name: "Sarah Miller",
    username: "sarah_m",
    avatar: "/placeholder.svg?height=40&width=40",
    followers: "3.2K",
  },
]

export function SuggestedUsers() {
  return (
    <Card className="ghibli-card">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <UserPlus className="w-5 h-5 text-primary" />
          Suggested for You
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {suggestedUsers.map((user) => (
          <div key={user.username} className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Avatar className="w-10 h-10">
                <AvatarImage src={user.avatar || "/placeholder.svg"} alt={user.name} />
                <AvatarFallback>{user.name.charAt(0)}</AvatarFallback>
              </Avatar>
              <div>
                <p className="font-medium">{user.name}</p>
                <p className="text-sm text-muted-foreground">
                  @{user.username} • {user.followers} followers
                </p>
              </div>
            </div>
            <Button size="sm" variant="outline" className="rounded-full bg-transparent">
              Follow
            </Button>
          </div>
        ))}
      </CardContent>
    </Card>
  )
}
