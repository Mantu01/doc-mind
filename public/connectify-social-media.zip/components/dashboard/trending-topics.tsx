import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { TrendingUp } from "lucide-react"

const trendingTopics = [
  { topic: "#StudioGhibli", posts: "12.5K" },
  { topic: "#Nature", posts: "8.2K" },
  { topic: "#Photography", posts: "6.7K" },
  { topic: "#Art", posts: "5.1K" },
  { topic: "#Magic", posts: "3.9K" },
]

export function TrendingTopics() {
  return (
    <Card className="ghibli-card">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <TrendingUp className="w-5 h-5 text-primary" />
          Trending Topics
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        {trendingTopics.map((item, index) => (
          <div key={item.topic} className="flex items-center justify-between">
            <div>
              <p className="font-medium text-primary hover:underline cursor-pointer">{item.topic}</p>
              <p className="text-sm text-muted-foreground">{item.posts} posts</p>
            </div>
            <Badge variant="secondary" className="text-xs">
              #{index + 1}
            </Badge>
          </div>
        ))}
      </CardContent>
    </Card>
  )
}
