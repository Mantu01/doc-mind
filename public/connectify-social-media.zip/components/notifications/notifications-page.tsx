"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Bell, Heart, MessageCircle, UserPlus, Share, Phone, Video, Users } from "lucide-react"

const mockNotifications = [
  {
    id: "1",
    type: "like",
    user: {
      name: "Alice Johnson",
      username: "alice_j",
      avatar: "/placeholder.svg?height=40&width=40",
    },
    content: "liked your post",
    postContent: "Beautiful sunset today! Nature never fails to amaze me 🌅",
    timestamp: "2 minutes ago",
    isRead: false,
  },
  {
    id: "2",
    type: "comment",
    user: {
      name: "Bob Smith",
      username: "bob_smith",
      avatar: "/placeholder.svg?height=40&width=40",
    },
    content: "commented on your post",
    comment: "Amazing shot! Where was this taken?",
    timestamp: "5 minutes ago",
    isRead: false,
  },
  {
    id: "3",
    type: "follow",
    user: {
      name: "Carol Davis",
      username: "carol_d",
      avatar: "/placeholder.svg?height=40&width=40",
    },
    content: "started following you",
    timestamp: "1 hour ago",
    isRead: true,
  },
  {
    id: "4",
    type: "message",
    user: {
      name: "David Chen",
      username: "david_c",
      avatar: "/placeholder.svg?height=40&width=40",
    },
    content: "sent you a message",
    message: "Hey! How are you doing?",
    timestamp: "2 hours ago",
    isRead: false,
  },
  {
    id: "5",
    type: "video_call",
    user: {
      name: "Emma Wilson",
      username: "emma_w",
      avatar: "/placeholder.svg?height=40&width=40",
    },
    content: "tried to video call you",
    timestamp: "3 hours ago",
    isRead: true,
  },
  {
    id: "6",
    type: "audio_call",
    user: {
      name: "Frank Miller",
      username: "frank_m",
      avatar: "/placeholder.svg?height=40&width=40",
    },
    content: "called you",
    timestamp: "4 hours ago",
    isRead: true,
  },
  {
    id: "7",
    type: "group",
    user: {
      name: "Sarah Johnson",
      username: "sarah_j",
      avatar: "/placeholder.svg?height=40&width=40",
    },
    content: "added you to a group",
    groupName: "Photography Enthusiasts",
    timestamp: "1 day ago",
    isRead: true,
  },
]

export function NotificationsPage() {
  const [notifications, setNotifications] = useState(mockNotifications)
  const [activeTab, setActiveTab] = useState("all")

  const markAsRead = (id: string) => {
    setNotifications((prev) => prev.map((notif) => (notif.id === id ? { ...notif, isRead: true } : notif)))
  }

  const markAllAsRead = () => {
    setNotifications((prev) => prev.map((notif) => ({ ...notif, isRead: true })))
  }

  const getNotificationIcon = (type: string) => {
    switch (type) {
      case "like":
        return <Heart className="w-4 h-4 text-red-500" />
      case "comment":
        return <MessageCircle className="w-4 h-4 text-blue-500" />
      case "follow":
        return <UserPlus className="w-4 h-4 text-green-500" />
      case "share":
        return <Share className="w-4 h-4 text-purple-500" />
      case "message":
        return <MessageCircle className="w-4 h-4 text-blue-500" />
      case "video_call":
        return <Video className="w-4 h-4 text-orange-500" />
      case "audio_call":
        return <Phone className="w-4 h-4 text-pink-500" />
      case "group":
        return <Users className="w-4 h-4 text-indigo-500" />
      default:
        return <Bell className="w-4 h-4 text-gray-500" />
    }
  }

  const getNotificationColor = (type: string) => {
    switch (type) {
      case "like":
        return "ghibli-accent-pink"
      case "comment":
        return "ghibli-accent-blue"
      case "follow":
        return "ghibli-accent-green"
      case "message":
        return "ghibli-accent-blue"
      case "video_call":
        return "ghibli-accent-orange"
      case "audio_call":
        return "ghibli-accent-pink"
      case "group":
        return "ghibli-accent-green"
      default:
        return "ghibli-card"
    }
  }

  const filterNotifications = (type: string) => {
    if (type === "all") return notifications
    return notifications.filter((notif) => notif.type === type)
  }

  const unreadCount = notifications.filter((notif) => !notif.isRead).length

  return (
    <div className="space-y-6">
      <Card className="ghibli-card ghibli-gradient-subtle">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <Bell className="w-5 h-5 text-primary" />
              Notifications
              {unreadCount > 0 && <Badge className="bg-red-500 text-white">{unreadCount}</Badge>}
            </CardTitle>
            {unreadCount > 0 && (
              <Button variant="outline" size="sm" onClick={markAllAsRead} className="bg-transparent">
                Mark all as read
              </Button>
            )}
          </div>
        </CardHeader>
      </Card>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-5 bg-card/50 backdrop-blur-sm">
          <TabsTrigger value="all">All</TabsTrigger>
          <TabsTrigger value="like">Likes</TabsTrigger>
          <TabsTrigger value="comment">Comments</TabsTrigger>
          <TabsTrigger value="follow">Follows</TabsTrigger>
          <TabsTrigger value="message">Messages</TabsTrigger>
        </TabsList>

        <TabsContent value={activeTab} className="space-y-3">
          {filterNotifications(activeTab).map((notification) => (
            <Card
              key={notification.id}
              className={`cursor-pointer transition-all duration-300 hover:shadow-lg ${
                notification.isRead
                  ? "ghibli-card"
                  : `${getNotificationColor(notification.type)} border-l-4 border-l-primary`
              }`}
              onClick={() => markAsRead(notification.id)}
            >
              <CardContent className="p-4">
                <div className="flex items-start gap-3">
                  <div className="relative">
                    <Avatar className="w-10 h-10">
                      <AvatarImage src={notification.user.avatar || "/placeholder.svg"} alt={notification.user.name} />
                      <AvatarFallback>{notification.user.name.charAt(0)}</AvatarFallback>
                    </Avatar>
                    <div className="absolute -bottom-1 -right-1 bg-background rounded-full p-1">
                      {getNotificationIcon(notification.type)}
                    </div>
                  </div>

                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <p className="font-medium">{notification.user.name}</p>
                      <p className="text-sm text-muted-foreground">{notification.content}</p>
                      {!notification.isRead && <div className="w-2 h-2 bg-primary rounded-full flex-shrink-0" />}
                    </div>

                    {notification.comment && (
                      <p className="text-sm text-muted-foreground mt-1 bg-muted/50 p-2 rounded-lg">
                        "{notification.comment}"
                      </p>
                    )}

                    {notification.postContent && (
                      <p className="text-sm text-muted-foreground mt-1 bg-muted/50 p-2 rounded-lg">
                        "{notification.postContent}"
                      </p>
                    )}

                    {notification.message && (
                      <p className="text-sm text-muted-foreground mt-1 bg-muted/50 p-2 rounded-lg">
                        "{notification.message}"
                      </p>
                    )}

                    {notification.groupName && (
                      <p className="text-sm text-muted-foreground mt-1 bg-muted/50 p-2 rounded-lg">
                        Group: {notification.groupName}
                      </p>
                    )}

                    <p className="text-xs text-muted-foreground mt-2">{notification.timestamp}</p>
                  </div>

                  {(notification.type === "video_call" || notification.type === "audio_call") && (
                    <div className="flex gap-2">
                      <Button size="sm" className="ghibli-button-blue">
                        Call Back
                      </Button>
                    </div>
                  )}

                  {notification.type === "follow" && (
                    <Button size="sm" className="ghibli-button">
                      Follow Back
                    </Button>
                  )}

                  {notification.type === "message" && (
                    <Button size="sm" variant="outline" className="bg-transparent">
                      Reply
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </TabsContent>
      </Tabs>
    </div>
  )
}
