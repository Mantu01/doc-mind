"use client"

import { useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { MapPin, Calendar, LinkIcon, Settings, MessageCircle, UserPlus, Users } from "lucide-react"
import { PostCard } from "@/components/posts/post-card"

const mockUserProfile = {
  id: "1",
  name: "John Doe",
  username: "john_doe",
  avatar: "/placeholder.svg?height=120&width=120",
  coverImage: "/placeholder.svg?height=200&width=800",
  bio: "Digital creator & Studio Ghibli enthusiast ✨ Sharing magical moments through art and photography 📸",
  location: "Tokyo, Japan",
  website: "https://johndoe.art",
  joinedDate: "March 2023",
  followers: 2847,
  following: 892,
  posts: 156,
  isFollowing: false,
  isOwnProfile: true,
}

const mockUserPosts = [
  {
    id: "1",
    user: {
      name: "John Doe",
      username: "john_doe",
      avatar: "/placeholder.svg?height=40&width=40",
    },
    content:
      "Just finished this amazing digital art piece inspired by Spirited Away! The colors came out so magical ✨",
    timestamp: "2 hours ago",
    likes: 124,
    comments: 18,
    shares: 7,
    isLiked: true,
    images: ["/placeholder.svg?height=300&width=400"],
  },
  {
    id: "2",
    user: {
      name: "John Doe",
      username: "john_doe",
      avatar: "/placeholder.svg?height=40&width=40",
    },
    content:
      "Beautiful sunset today! Nature never fails to amaze me. Sometimes the real world is more magical than any fantasy 🌅",
    timestamp: "1 day ago",
    likes: 89,
    comments: 12,
    shares: 4,
    isLiked: false,
    images: ["/placeholder.svg?height=300&width=400"],
  },
  {
    id: "3",
    user: {
      name: "John Doe",
      username: "john_doe",
      avatar: "/placeholder.svg?height=40&width=40",
    },
    content:
      "Working on a new photography series inspired by Studio Ghibli films. Each shot captures the magic hidden in everyday moments ✨📸",
    timestamp: "3 days ago",
    likes: 156,
    comments: 24,
    shares: 11,
    isLiked: true,
    images: [],
  },
]

const mockFollowers = [
  {
    id: "1",
    name: "Alice Johnson",
    username: "alice_j",
    avatar: "/placeholder.svg?height=40&width=40",
    bio: "Digital artist & nature lover",
    isFollowing: true,
  },
  {
    id: "2",
    name: "Bob Smith",
    username: "bob_smith",
    avatar: "/placeholder.svg?height=40&width=40",
    bio: "Photography enthusiast",
    isFollowing: false,
  },
  {
    id: "3",
    name: "Carol Davis",
    username: "carol_d",
    avatar: "/placeholder.svg?height=40&width=40",
    bio: "UI/UX Designer",
    isFollowing: true,
  },
]

const mockFollowing = [
  {
    id: "1",
    name: "Studio Ghibli",
    username: "studioghibli",
    avatar: "/placeholder.svg?height=40&width=40",
    bio: "Official Studio Ghibli account",
    isFollowing: true,
  },
  {
    id: "2",
    name: "Nature Photography",
    username: "naturephoto",
    avatar: "/placeholder.svg?height=40&width=40",
    bio: "Capturing nature's beauty",
    isFollowing: true,
  },
]

export function ProfilePage() {
  const [activeTab, setActiveTab] = useState("posts")
  const [isFollowing, setIsFollowing] = useState(mockUserProfile.isFollowing)

  const handleFollow = () => {
    setIsFollowing(!isFollowing)
  }

  return (
    <div className="space-y-6">
      {/* Cover Image & Profile Info */}
      <Card className="ghibli-card overflow-hidden">
        <div className="relative">
          {/* Cover Image */}
          <div className="h-48 bg-gradient-to-r from-green-400 via-blue-400 to-pink-400 relative">
            <div className="absolute inset-0 bg-black/20"></div>
          </div>

          {/* Profile Picture */}
          <div className="absolute -bottom-16 left-6">
            <Avatar className="w-32 h-32 border-4 border-background">
              <AvatarImage src={mockUserProfile.avatar || "/placeholder.svg"} alt={mockUserProfile.name} />
              <AvatarFallback className="text-4xl">{mockUserProfile.name.charAt(0)}</AvatarFallback>
            </Avatar>
          </div>

          {/* Action Buttons */}
          <div className="absolute top-4 right-4 flex gap-2">
            {mockUserProfile.isOwnProfile ? (
              <Button variant="outline" className="bg-background/80 backdrop-blur-sm">
                <Settings className="w-4 h-4 mr-2" />
                Edit Profile
              </Button>
            ) : (
              <>
                <Button variant="outline" className="bg-background/80 backdrop-blur-sm">
                  <MessageCircle className="w-4 h-4" />
                </Button>
                <Button
                  onClick={handleFollow}
                  className={isFollowing ? "bg-background/80 backdrop-blur-sm text-foreground" : "ghibli-button"}
                  variant={isFollowing ? "outline" : "default"}
                >
                  {isFollowing ? (
                    <>
                      <Users className="w-4 h-4 mr-2" />
                      Following
                    </>
                  ) : (
                    <>
                      <UserPlus className="w-4 h-4 mr-2" />
                      Follow
                    </>
                  )}
                </Button>
              </>
            )}
          </div>
        </div>

        <CardContent className="pt-20 pb-6">
          <div className="space-y-4">
            <div>
              <h1 className="text-2xl font-bold">{mockUserProfile.name}</h1>
              <p className="text-muted-foreground">@{mockUserProfile.username}</p>
            </div>

            <p className="text-sm leading-relaxed">{mockUserProfile.bio}</p>

            <div className="flex flex-wrap items-center gap-4 text-sm text-muted-foreground">
              <div className="flex items-center gap-1">
                <MapPin className="w-4 h-4" />
                {mockUserProfile.location}
              </div>
              <div className="flex items-center gap-1">
                <LinkIcon className="w-4 h-4" />
                <a href={mockUserProfile.website} className="text-primary hover:underline">
                  johndoe.art
                </a>
              </div>
              <div className="flex items-center gap-1">
                <Calendar className="w-4 h-4" />
                Joined {mockUserProfile.joinedDate}
              </div>
            </div>

            <div className="flex items-center gap-6 text-sm">
              <div className="flex items-center gap-1">
                <span className="font-semibold">{mockUserProfile.posts.toLocaleString()}</span>
                <span className="text-muted-foreground">Posts</span>
              </div>
              <div className="flex items-center gap-1 cursor-pointer hover:underline">
                <span className="font-semibold">{mockUserProfile.followers.toLocaleString()}</span>
                <span className="text-muted-foreground">Followers</span>
              </div>
              <div className="flex items-center gap-1 cursor-pointer hover:underline">
                <span className="font-semibold">{mockUserProfile.following.toLocaleString()}</span>
                <span className="text-muted-foreground">Following</span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Profile Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-3 bg-card/50 backdrop-blur-sm">
          <TabsTrigger value="posts">Posts</TabsTrigger>
          <TabsTrigger value="followers">Followers</TabsTrigger>
          <TabsTrigger value="following">Following</TabsTrigger>
        </TabsList>

        <TabsContent value="posts" className="space-y-4">
          {mockUserPosts.map((post) => (
            <PostCard key={post.id} post={post} />
          ))}
        </TabsContent>

        <TabsContent value="followers" className="space-y-4">
          {mockFollowers.map((user) => (
            <Card key={user.id} className="ghibli-card">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <Avatar>
                      <AvatarImage src={user.avatar || "/placeholder.svg"} alt={user.name} />
                      <AvatarFallback>{user.name.charAt(0)}</AvatarFallback>
                    </Avatar>
                    <div>
                      <p className="font-medium">{user.name}</p>
                      <p className="text-sm text-muted-foreground">@{user.username}</p>
                      <p className="text-xs text-muted-foreground">{user.bio}</p>
                    </div>
                  </div>
                  <Button
                    size="sm"
                    variant={user.isFollowing ? "outline" : "default"}
                    className={user.isFollowing ? "bg-transparent" : "ghibli-button"}
                  >
                    {user.isFollowing ? "Following" : "Follow Back"}
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </TabsContent>

        <TabsContent value="following" className="space-y-4">
          {mockFollowing.map((user) => (
            <Card key={user.id} className="ghibli-card">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <Avatar>
                      <AvatarImage src={user.avatar || "/placeholder.svg"} alt={user.name} />
                      <AvatarFallback>{user.name.charAt(0)}</AvatarFallback>
                    </Avatar>
                    <div>
                      <p className="font-medium">{user.name}</p>
                      <p className="text-sm text-muted-foreground">@{user.username}</p>
                      <p className="text-xs text-muted-foreground">{user.bio}</p>
                    </div>
                  </div>
                  <Button size="sm" variant="outline" className="bg-transparent">
                    Following
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </TabsContent>
      </Tabs>
    </div>
  )
}
